Java ATM Machine using Swing

# Description
This Java ATM Machine application is built using Swing for the GUI. It simulates basic ATM functionalities, providing users with a secure and easy-to-use interface for managing their bank accounts.

# Features
1. Create Account: Users can create a new bank account.
2. Login: Users can log in using their card number and PIN for security.
3. Transactions: 
  - Deposit: Add money to the account.
  - Withdrawal: Withdraw money from the account.
  - Fast Cash: Quickly withdraw a pre-set amount of money.
4. Change PIN: Users can change their PIN for security purposes.
5. Balance Enquiry: Check the current balance in the account.
6. Mini Statement: View recent transactions.

# Installation
1. Java Development Kit (JDK) 8 or higher
2. An IDE (Neatbeans is used here)
3. Database for storing data (MySQL is used here)

# Usage
1. Create an account:
  - Open the application.
  - Click on "Signup".
  - Enter the required details and submit the form.
2. Login:
  - Open the application.
  - Enter your card number and PIN.
  - Click "Login".
3. Perform Transactions:
  - Once logged in, navigate to the desired transaction section (Deposit, Withdrawal, Fast Cash).
  - Follow the prompts to complete the transaction.
4. Change PIN:
  - Navigate to the "Change PIN" section.
  - Enter the current PIN and the new PIN.
  - Submit the form to update the PIN.
5. Check Balance and view Mini Statement:
  - Navigate to the "Balance Enquiry" or "Mini Statement" section.
  - Follow the prompts to view your account details.
