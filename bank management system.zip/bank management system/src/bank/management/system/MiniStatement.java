package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;



public class MiniStatement extends JFrame implements ActionListener {

    String pin;

    MiniStatement(String pin){

        this.pin = pin;

        setLayout (null);

        setTitle ("MINI STATEMENT");

        JLabel text = new JLabel();
        text.setBounds(35, 140, 400, 200);
        add (text);

        JLabel bank = new JLabel("PROJECT BANK");
        bank.setFont(new Font("Osward", Font.BOLD, 20));
        bank.setBounds(140, 50, 200,  30);
        add(bank);

        JLabel mini = new JLabel();
        mini.setBounds(35, 100, 300,  30);
        add(mini);

        JLabel card = new JLabel();
        card.setBounds(35, 400, 300,  20);
        add(card);

        try{
            Conn conn = new Conn();
            ResultSet rs = conn.s.executeQuery("select * from login where pin = '"+pin+"'");
            while (rs.next()) {
                mini.setText("Card Number: " + rs.getString("cardnumber").substring(0, 4) + "XXXXXXXX" + rs.getString("cardnumber").substring(12));
            }
        }catch(Exception ex){
            System.out.println(ex);
        }
        try{
            int bal = 0; 
            Conn conn = new Conn();          
            ResultSet rs = conn.s.executeQuery("select * from bank where pin = '"+pin+"'");
            while (rs.next()) {
                text.setText(text.getText() + "<html>" + rs.getString("date") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("type") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("amount") + "<br><br><html>");
                if (rs.getString("type").equals("Deposit")){
                    bal +=  Integer.parseInt(rs.getString("amount"));
                }else{
                    bal -=  Integer.parseInt(rs.getString("amount"));
                }
            }
            card.setText("Your current account balance is Rs "+bal);
        }catch(Exception e){
            System.out.println(e);
        }
        
        getContentPane().setBackground(Color.white);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize (450,600);
        setVisible (true);
        setLocation (310,50); 
        
        JButton exit = new JButton("Back");
        exit.setBounds(345,490,80,25);
        exit.addActionListener(this);
        exit.setBackground(Color.BLACK);
        exit.setForeground(Color.WHITE);
        add(exit);
        
    }

    public void actionPerformed(ActionEvent ae) {
         setVisible(false);
         new Transaction(pin).setVisible(true);
    }
    
    public static void main (String[] args){
        new MiniStatement("").setVisible(true);
    }
}
